<?php
namespace OmekaHelpGuide;

use Laminas\Mvc\MvcEvent;
use Omeka\Module\AbstractModule;

// Make sure the module's own classes load.
spl_autoload_register(function ($class) {
    if (strpos($class, 'OmekaHelpGuide\\') === 0) {
        $file = __DIR__ . '/src/' . str_replace('\\', '/', substr($class, strlen('OmekaHelpGuide\\'))) . '.php';
        if (is_file($file)) {
            require_once $file;
        }
    }
});

class Module extends AbstractModule
{
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function onBootstrap(MvcEvent $event)
    {
        parent::onBootstrap($event);
        // Every logged-in user can read the guide.
        $acl = $this->getServiceLocator()->get('Omeka\Acl');
        $acl->allow(null, 'OmekaHelpGuide\Controller\Admin\Index');
    }
}
