<?php
namespace OmekaHelpGuide;

return [
    'view_manager' => [
        'template_path_stack' => [
            dirname(__DIR__) . '/view',
        ],
    ],
    'controllers' => [
        'invokables' => [
            'OmekaHelpGuide\Controller\Admin\Index' => Controller\Admin\IndexController::class,
        ],
    ],
    'router' => [
        'routes' => [
            'admin' => [
                'child_routes' => [
                    'omeka-help-guide' => [
                        'type' => \Laminas\Router\Http\Literal::class,
                        'options' => [
                            'route' => '/omeka-help-guide',
                            'defaults' => [
                                // Overrides the admin route's Omeka\Controller\Admin namespace.
                                '__NAMESPACE__' => 'OmekaHelpGuide\Controller\Admin',
                                'controller' => 'Index',
                                'action' => 'index',
                            ],
                        ],
                    ],
                ],
            ],
        ],
    ],
    'navigation' => [
        'AdminModule' => [
            [
                'label' => 'Help guide', // @translate
                'route' => 'admin/omeka-help-guide',
                'resource' => 'OmekaHelpGuide\Controller\Admin\Index',
                'class' => 'o-icon-help',
            ],
        ],
    ],
];
