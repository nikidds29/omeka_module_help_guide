<?php
namespace OmekaHelpGuide\Controller\Admin;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class IndexController extends AbstractActionController
{
    public function indexAction()
    {
        $view = new ViewModel;
        $view->setTemplate('omeka-help-guide/admin/index/index');
        return $view;
    }
}
