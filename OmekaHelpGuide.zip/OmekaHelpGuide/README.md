# Omeka-S Help Guide (Omeka S module)

Adds a **Help guide** link to the Omeka-S admin menu (under Modules). It opens an illustrated guide to finding, adding and linking records: resource templates, item sets, advanced search, controlled vocabularies, linked items, media, mapping, applying templates, and sites.

Every logged-in user can open the guide.

## Requirements
- Omeka-S 4.x

## Install
1. Upload the `OmekaHelpGuide` folder to your Omeka-S `modules/` folder. The folder must be named exactly `OmekaHelpGuide`.
2. In the Omeka-S admin, go to **Modules** and click **Install** next to *Omeka-S Help Guide*.
3. **Help guide** now appears in the left-hand menu under Modules.

## Customising
- **Text:** all the guide text is in `view/omeka-help-guide/admin/index/index.phtml`.
- **Screenshots:** in `asset/img/`, numbered in the order they appear. To replace one, upload a new file with the same name. If a file the guide expects is missing, the guide shows a dashed placeholder box with that file name.
- **Styles:** `asset/css/help-guide.css`.

## Uninstall
Go to **Modules**, click **Uninstall** next to *Omeka-S Help Guide*, then delete the `OmekaHelpGuide` folder. The module doesn't store anything in the database.
